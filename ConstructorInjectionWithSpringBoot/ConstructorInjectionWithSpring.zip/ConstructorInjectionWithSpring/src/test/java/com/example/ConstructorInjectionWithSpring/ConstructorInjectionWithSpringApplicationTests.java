package com.example.ConstructorInjectionWithSpring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConstructorInjectionWithSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
